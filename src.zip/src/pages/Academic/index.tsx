export { default } from './AcademicPage'
